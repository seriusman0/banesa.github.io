<nav id="menu2" class="bar bar-2 hidden-xs ">
    <div class="container">
        <div class="row">
            <div class="col-lg-2 text-center text-left-sm hidden-xs order-lg-2">
                <div class="bar__module">
                    <a href="index.html">
                        <img class="logo logo-dark" alt="logo" src="img/logo/logo5.png" />
                        <img class="logo logo-light" alt="logo" src="img/logo/logo5.png" />
                    </a>
                </div>
                <!--end module-->
            </div>
            <div class="col-lg-5 order-lg-1">
                <div class="">
                    <ul class="menu-horizontal text-left">
                        <li class="dropdown">
                            <a href="#">
                                Home
                            </a>
                        </li>
                        <li class="dropdown">
                            <a href="#">
                                Product
                            </a>
                        </li>
                        <li class="dropdown">
                            <a href="#">
                                About
                            </a>
                        </li>

                    </ul>
                </div>
                <!--end module-->

            </div>
            <!--end of row-->
        </div>
        <!--end of container-->
</nav>